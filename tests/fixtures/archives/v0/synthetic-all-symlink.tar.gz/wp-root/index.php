<?php
// synthetic v0 fixture
