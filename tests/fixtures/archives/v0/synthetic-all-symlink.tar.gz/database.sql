-- MySQL dump (synthetic v0 fixture)
DROP TABLE IF EXISTS `wp_options`;
CREATE TABLE `wp_options` (`option_id` INT, `option_name` VARCHAR(191));
INSERT INTO `wp_options` VALUES (1,'siteurl');
